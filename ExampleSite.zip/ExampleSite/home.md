# Home 



## Welcome to UCSB Physics 6CL



Physics 6CL ivestigates optics. [fn]Curabitur varius ipsum in leo suscipit maximus vitae eu magna. Morbi posuere, dolor ac malesuada sagittis, est elit rutrum quam, at vestibulum nisi risus ut lorem[/fn]. Duis efficitur mauris quis lectus mollis, et sagittis nisl lacinia. Etiam condimentum venenatis sem, sed ullamcorper augue posuere nec. Fusce pretium nibh et sagittis gravida. Nullam vehicula nisi sit amet tempor tincidunt. Vestibulum pharetra faucibus ex nec pretium. 

Donec malesuada quam facilisis, auctor tellus sed, pretium neque. Vestibulum erat dolor, aliquet id facilisis sit amet, eleifend nec massa. Maecenas ut luctus leo, non commodo magna. Sed consequat, orci sit amet fermentum placerat, purus quam porta orci, et fringilla diam justo non quam. Nullam eleifend, ante a dictum bibendum, leo orci tincidunt augue, vel ullamcorper purus purus et tellus. Quisque sit amet imperdiet dui, vel lobortis diam. Curabitur pellentesque eros quis molestie tincidunt.

### Contact Information

######

Your Teaching Assistant (TA) is your first point of contact for this course. 
      Please reach out to them if you have questions about labs, completing your assignments, grading, regrade requests, or attendance. 
:::ContactTA
:::

The course Faculty are here to help with more complex issues, working behind the scenes to ensure the labs run smoothly. Please contact a Faculty member if you have specific issues reguarding DSP and other accomodations, errors in the lab manual, problems with equipment, or have witnessed/been a victim of any kind of harassment `


:::ContactFA
:::




## Schedule (Fall 2021)

The table below shows the weekly schedule

:::Table
| Week      | Lab Opens | Report Due  | Final Deadline|
|---        | ---       | ---         | ---           |
|Week 1     | Monday @ Noon   | Next Monday @ Noon | Next Friday @ Noon       |
|Week 2     | Monday @ Noon   | Next Monday @ Noon | Next Friday @ Noon       |
|Week 3     | Monday @ Noon   | Next Monday @ Noon | Next Friday @ Noon       |


:::
## Policies

### Late Submissions